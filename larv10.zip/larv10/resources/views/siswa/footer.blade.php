</body>
</html>

<script>
    //masage with toaster
    @if(session()->has('succes'))

    alert('{{ session('succes') }}');

    @elseif(session()->has('error'))
        alert('{{ session('error') }}')

        @endif
</script>