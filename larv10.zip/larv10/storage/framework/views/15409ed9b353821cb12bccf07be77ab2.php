<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel 10</title>
</head>
<body>
    
<?php if(auth()->guard()->guest()): ?>
<?php else: ?>

    <a class="nav-link" href="<?php echo e(route('siswa.index')); ?>">Data siswa</a>
    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
        document.getElementById('logout-form').submit();" >Logout</a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    </form>
<?php endif; ?>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\larv10\resources\views/auth/layouts.blade.php ENDPATH**/ ?>