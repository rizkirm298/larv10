<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Latihan Laravel 10</title>
</head>
<body>


	<table>
		<tr>
			<td colspan="3" style="text-align: center;"><img src="<?php echo e(asset('storage/siswa/'.$siswa->image)); ?>" width="120px" hight="120px" alt=""></td>
		</tr>
		<tr>
			<th>Nama</th>
			<td>: <?php echo e($siswa->nama); ?></td>
		</tr>
		<tr>
			<th>Jenis Kelamin</th>
			<td>: <?php echo e($siswa->jk); ?></td>
		</tr>
		<tr>
			<th>Kelas</th>
			<td>: <?php echo e($siswa->kelas); ?></td>
		</tr>
		<tr>
			<th>Jurusan</th>
			<td>: <?php echo e($siswa->jurusan); ?></td>
		</tr>
	</table>

	

</body>
</html>
<?php /**PATH C:\xampp\htdocs\larv10\resources\views/siswa/show.blade.php ENDPATH**/ ?>