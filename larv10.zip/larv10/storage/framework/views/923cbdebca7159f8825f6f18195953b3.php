<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=10">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>latihan laravel 10</title>
    <style>
        table{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0px;
        }
        table, th, td{
            border: 1px solid;
        }
    </style>
</head>
<body>
    <h1>Tambah Siswa</h1>
    <a href="<?php echo e(route('siswa.index')); ?>">Kembali</a>

    <form action="<?php echo e(route('siswa.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label>Nama Siswa</label>
    <input type="text" name="nama"> <br><br>
    <label>JK</label><br>
    <select name="jk" required>
        <option>Pilih JK</option>
        <option value="Laki-laki">Laki-Laki</option>
        <option value="Perempuan">Perempuan</option>
    </select>
    <br><br>
    <label>Kelas</label><br>
    <select name="kelas" required>
        <option>Pilih Kelas</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
    </select>
    <br><br>
    <label>Jurusan</label>
    <select name="jurusan" required>
        <option>Pilih Jurusan</option>
        <option value="RPL">RPL</option>
        <option value="TKJ">TKJ</option>
        <option value="TBR">TKR</option>
    </select>
    <br><br>
    <label>Foto Siswa</label>
    <input type="file" name="image">
    <br><br>
    <button type="submit">SIMPAN DATA</button>
    <button type="reset">RESET FORM</button>
</form>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\larv10\resources\views/siswa/create.blade.php ENDPATH**/ ?>