<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>latihan Laravel 10</title>
    <style type="text/css">
    table{
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0px;
    }
    table, th, td{
        border: 1px solid;
    }

    </style>
</head>
<body>
    <h1>Data Siswa</h1>
    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    </form>
    <br>
    <a href="<?php echo e(route('siswa.create')); ?>">Tambah Siswa</a>

    <table class="tabel">
        <tr>
            <th>nama</th>
            <th>Jenis Kelamin</th>
            <th>Kelas</th>
            <th>Jurusan</th>
            <th>Foto</th>
            <th>Aksi</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($siswa->nama); ?></td>
                <td><?php echo e($siswa->jk); ?></td>
                <td><?php echo e($siswa->kelas); ?></td>
                <td><?php echo e($siswa->jurusan); ?></td>
                <td>
                    <img src="<?php echo e(asset('/storage/siswa/' . $siswa->image)); ?>" width="120px" hight="120px" >
                </td>
                <td>
                    <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('siswa.destroy', $siswa->id)); ?>" method="POST">
                    <a href="<?php echo e(route('siswa.show', $siswa->id)); ?>" class="btn btn-sm btn-dark">SHOW</a>
                    <a href="<?php echo e(route('siswa.edit', $siswa->id)); ?>" class="btn btn-sm btn-dark">EDIT</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">HAPUS</button>
                </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </table>
    <?php echo e($siswas->links()); ?>

</body>
</html>

<script>
    //masage with toaster
    <?php if(session()->has('succes')): ?>

    alert('<?php echo e(session('succes')); ?>');

    <?php elseif(session()->has('error')): ?>
        alert('<?php echo e(session('error')); ?>')

        <?php endif; ?>
</script><?php /**PATH C:\xampp\htdocs\larv10\resources\views/siswa/index.blade.php ENDPATH**/ ?>