<?php

namespace App\Http\Controllers;

use App\Models\Siswa;
use Illuminate\Http\Response;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SiswaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(): View
    {
        //get data db
        $siswas = Siswa::latest()->paginate(5);
        return view('siswa.index', compact('siswas'));
    }
    
    public function create(): View
    {
        return view('siswa.create');
    }


    public function show(string $id): view
    {
        //get post by ID
        $siswa = Siswa::findOrfail($id);

        //render view with post
        return view('siswa.show', compact('siswa'));

    {
    //get post by ID
    $post = Siswa::findOrfail($id);

    //render view with post
    return view('siswa.update', compact('post'));
    }
}   

public function store(Request $request): RedirectResponse
{
    //validate form
    $this->validate($request, [
        'nama'   => 'required|min:3',
        'jk'    => 'required',
        'image'   => 'required|image|mimes:jpeg,png,jpg|max:2048',
        'jurusan'   => 'required',
        'kelas'   => 'required'
    ]);
    // upload image
    $image = $request->file('image');
    $image->storeAs('public/siswa', $image->hashName());
    
    //create
    Siswa::create([
        'nama'     => $request->nama,
        'jk'    => $request->jk,
        'jurusan'    => $request->jurusan,
        'kelas'    => $request->kelas,
        'image'    => $image->hashName()
    ]);
    
    //redirect to index
    return redirect()->route('siswa.index')->with(['success' => 'Data Berhasil Disimpan']);
}


public function edit(string $id): View
{
    //get post by ID
    $siswas = Siswa::findOrFail($id);

    //render view with post
    return view('siswa.edit', compact('siswas'));
}

public function update(Request $request, $id): RedirectResponse
{
    //validate form
    $this->validate($request, [
        'nama'      => 'required|min:3',
        'jk'     => 'required',
        'image'    => 'required|image|mimes:jpeg,png,jpg|max:2048',
        'jurusan'     => 'required',
        'kelas'   => 'required',
    ]);
    //get post by ID
    $post = Siswa::findOrFail($id);

    //check if image is uploaded
    if ($request->hasFile('image')) {
        //upload new image
        $image = $request->file('image');
        $image->storeAs('public/siswa', $image->hashName());
        //delete old image
        Storage::delete('public/siswa/'.    $post->image);
        //update post with new image
        $post->update([
            'nama'    => $request->nama,
            'jk'   => $request->jk,
            'jurusan'   => $request->jurusan,
            'kelas'   => $request->kelas,
            'image'   => $image->hashName()
        ]);
    } else {

        //update post without image
        $post->update([
            'nama'    => $request->nama,
            'jk'   => $request->jk,
            'jurusan'    => $request->jurusan,
            'kelas'  => $request->kelas
        ]);
    }
    //redirect to index
    return redirect()->route('siswa.index')->with(['success' => 'Data Berhasil Diubah!']);
}

    // Hapus data
    public function destroy($id): RedirectResponse
    {
        //get post by ID
        $post = Siswa::findOrFail($id);

        //delete image
        Storage::delete('public/siswa/'. $post->image);

        //delete post
        $post->delete();

        //redirect to index
        return redirect()->route('siswa.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }

}